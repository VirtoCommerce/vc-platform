﻿angular.module('testModule1.blades.blade1', [])
.controller('testModule1.blade1Controller', ['$scope', 'platformWebApp.bladeNavigationService', function ($scope, bladeNavigationService) {

	$scope.data = "testModule1 content";
	$scope.blade.title = "testModule1 title";
    $scope.blade.isLoading = false;
}]);
