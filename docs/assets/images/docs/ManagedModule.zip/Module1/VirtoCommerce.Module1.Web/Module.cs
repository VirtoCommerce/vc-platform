﻿using VirtoCommerce.Platform.Core.Modularity;

namespace VirtoCommerce.Module1.Web
{
    public class Module : IModule
    {
        public void SetupDatabase(SampleDataLevel sampleDataLevel)
        {
        }
        public void Initialize()
        {
        }
        public void PostInitialize()
        {
        }
    }
}
